Project: Merchant's Guide to the Galaxy

Technologies: Spring Boot, Spring Shell

Build: Maven

IDE used: Eclipse Photon

Execute: All commands need to be prefixed with "vp ". For example -
shell> vp glob is M
shell> vp prok is C
shell> vp how much is glob prok glob pish tegj abcd xcvb ?