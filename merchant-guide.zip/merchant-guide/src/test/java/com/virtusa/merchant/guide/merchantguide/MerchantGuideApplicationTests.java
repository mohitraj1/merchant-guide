package com.virtusa.merchant.guide.merchantguide;

//@RunWith(SpringRunner.class)
class MerchantGuideApplicationTests {

	  public void contextLoads() {
	
	  }

}
