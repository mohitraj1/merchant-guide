package com.virtusa.merchant.guide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantGuideApplication  {

	public static void main(String[] args) {
		SpringApplication.run(MerchantGuideApplication.class, args);
	}

}
