package com.virtusa.merchant.guide.util;

public enum InputTypeEnum  {
	ROMAN,
	CREDIT,
	ROMAN_QUERY,
	CREDIT_QUERY,
	UNKNOWN;
}
