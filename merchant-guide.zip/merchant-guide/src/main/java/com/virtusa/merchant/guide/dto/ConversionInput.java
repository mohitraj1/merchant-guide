package com.virtusa.merchant.guide.dto;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.merchant.guide.util.InputTypeEnum;

public class ConversionInput {

	private List<String> tokens = new ArrayList<String>();
	private InputTypeEnum inputType;
	private Long credits;
	private String romanChar;
	private String metal;
	
	public List<String> getTokens() {
		return tokens;
	}
	public void setTokens(List<String> tokens) {
		this.tokens = tokens;
	}
	public InputTypeEnum getInputType() {
		return inputType;
	}
	public void setInputType(InputTypeEnum inputType) {
		this.inputType = inputType;
	}
	public Long getCredits() {
		return credits;
	}
	public void setCredits(Long credits) {
		this.credits = credits;
	}
	public String getRomanChar() {
		return romanChar;
	}
	public void setRomanChar(String romanChar) {
		this.romanChar = romanChar;
	}
	public String getMetal() {
		return metal;
	}
	public void setMetal(String metal) {
		this.metal = metal;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Tokens: ");
		sb.append(this.tokens);
		sb.append("\r\n");
		sb.append("Input type: ");
		sb.append(this.inputType);
		sb.append("\r\n");
		sb.append("Credit: ");
		sb.append(this.credits);
		sb.append("\r\n");
		sb.append("RomanChar: ");
		sb.append(this.romanChar);
		sb.append("\r\n");
		sb.append("Metal: ");
		sb.append(this.metal);
		sb.append("\r\n");
		return sb.toString();
	}
}
