package com.virtusa.merchant.guide.util;

import java.util.HashMap;
import java.util.Map;

public class Constants {

	public static final String IS = " is ";
	public static final String QM = "?";
	public static final String CREDITS = "credits";
	public static final String HOW_MUCH_IS = "how much" + IS;
	public static final String HOW_MANY_CREDITS = "how many credits" + IS;
	
	public static final String[] ROMAN_CHARS_SMALL = {"i", "v", "x", "l", "c", "d", "m"};
	public static final Map<String, Integer> ROMAN_CHARS_MAP = new HashMap<String, Integer>();
	static {
		ROMAN_CHARS_MAP.put("i", 1);
		ROMAN_CHARS_MAP.put("v", 5);
		ROMAN_CHARS_MAP.put("x", 10);
		ROMAN_CHARS_MAP.put("l", 50);
		ROMAN_CHARS_MAP.put("c", 100);
		ROMAN_CHARS_MAP.put("d", 500);
		ROMAN_CHARS_MAP.put("m", 1000);
	}
	
	
	public static Map<String, String> ROMAN_REGISTER = new HashMap<String, String>();
	public static Map<String, Long> CREDIT_REGISTER = new HashMap<String, Long>();
	public static Map<String, Double> METAL_REGISTER = new HashMap<String, Double>();
	
}
