package com.virtusa.merchant.guide.util;

import static com.virtusa.merchant.guide.util.Constants.*;

import java.util.Arrays;
import java.util.List;

/**
 * Class to validate the different validates based on rules applied.
 * 
 * @author Mohit Raj
 *
 */
public class CommandValidator {

	public static boolean validate(List<String> words) {
		String sentence = String.join(" ", words).toLowerCase();
		
		return rule1(sentence) || rule2(sentence) || rule3(sentence) || rule4(sentence);
	}
	
	/**
	 * Ending in Roman chars and preceeded by "is"
	 * 
	 * @return true: if rule is passed, else false
	 */
	private static boolean rule1(String input) {
		List<String> romanChars = Arrays.asList(Constants.ROMAN_CHARS_SMALL);
		Character lastChar = input.charAt(input.length() - 1);
		if (romanChars.contains(lastChar.toString())) {
			return input.endsWith(IS + lastChar); 
		}
		return false;
	}

	/**
	 * Ends with "Credits"
	 * 
	 * @return true: if rule is passed, else false
	 */
	private static boolean rule2(String input) {
		return input.endsWith(CREDITS);
	}

	/**
	 * Starting with "how much is" AND ends with "?"
	 * 
	 * @return true: if rule is passed, else false
	 */
	private static boolean rule3(String input) {
		if (input.endsWith(QM)) {
			return input.startsWith(HOW_MUCH_IS); 
		}
		return false;
	}

	/**
	 * Starting with "how many Credits is" AND ends with "?"
	 * 
	 * @return true: if rule is passed, else false
	 */
	private static boolean rule4(String input) {
		if (input.endsWith(QM)) {
			return input.startsWith(HOW_MANY_CREDITS); 
		}
		return false;
	}
	
	public static boolean validate(String input) {
		boolean resultRule5 = rule5(input, "iiii") && rule5(input, "xxxx") && rule5(input, "cccc") && rule5(input, "mmmm");
		boolean resultRule6 = rule6(input, "d") && rule6(input, "l") && rule6(input, "v");

		return resultRule5 && resultRule6;
	}
	
	private static boolean rule5(String input, String rule) {
		return input.indexOf(rule) == -1;
	}

	private static boolean rule6(String input, String rule) {
		return input.split(rule).length < 3;
	}
	
	public static boolean canBeSubtracted(String input1, String input2) {
		
		switch (input1) {
			case "i":
				return input2.equals("v") || input2.equals("x");
		
			case "x":
				return input2.equals("l") || input2.equals("c");
			
			case "c":
				return input2.equals("d") || input2.equals("m");
			
			case "v":
				return false;
				
			case "l":
				return false;
			
			case "d":
				return false;
				
			default:
				return false;
		}

	}
	
}
