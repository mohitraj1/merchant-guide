package com.virtusa.merchant.guide.aop;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.virtusa.merchant.guide.util.CommandValidator;

/**
 * Automatically invoked for each of parse request. So every parse request does
 * not require special call to validate.
 * 
 * @author Mohit Raj
 *
 */
@Aspect
@Component
public class ValidationAspect {
	
	@Pointcut("execution(* com.virtusa.merchant.guide.util.CommandParser.*(..))")
    public void parseMethod() {};

	@Around("parseMethod())")
    public Object  profileParseMethod(ProceedingJoinPoint pjp) throws Throwable 
    {
		Object value = null;
    	Object[] args = pjp.getArgs();
    	boolean isValid = CommandValidator.validate((List<String>)args[0]);
		if (isValid) {
			value = pjp.proceed();
		} 

        return value;
    }
}
