package com.virtusa.merchant.guide.util;

import static com.virtusa.merchant.guide.util.Constants.*;

import java.util.List;

import org.springframework.stereotype.Component;

import com.virtusa.merchant.guide.dto.ConversionInput;

/**
 * Class for parsing different commands. Parsing is done based on presence and position of various tokens such as ? and is
 * 
 * @author Mohit Raj
 *
 */
@Component
public class CommandParser {

	public ConversionInput parse(List<String> command) {
		command.replaceAll(String::toLowerCase);
		
		ConversionInput ci = new ConversionInput();
		int whereIs = command.indexOf(IS.trim());
		int whereQM = command.indexOf(QM.trim());
		if (whereQM == -1) {
			if (command.contains(CREDITS)) {
				ci.getTokens().addAll(command.subList(0, whereIs - 1));
				ci.setInputType(InputTypeEnum.CREDIT);
				ci.setCredits(Long.valueOf(command.get(whereIs + 1)));
				ci.setMetal(command.get(whereIs - 1));
			} else {
				ci.getTokens().addAll(command.subList(0, whereIs));
				ci.setInputType(InputTypeEnum.ROMAN);
				ci.setRomanChar(command.get(whereIs + 1));
			}
		} else {
			int metalIndex = command.contains(CREDITS) ? whereQM -1 : whereQM;
			ci.getTokens().addAll(command.subList(whereIs + 1, metalIndex));
			ci.setInputType(command.contains(CREDITS) ? InputTypeEnum.CREDIT_QUERY : InputTypeEnum.ROMAN_QUERY);
			ci.setMetal(command.contains(CREDITS) ? command.subList(whereQM - 1, whereQM).get(0) : null);
		}

		return ci;
	}
}
