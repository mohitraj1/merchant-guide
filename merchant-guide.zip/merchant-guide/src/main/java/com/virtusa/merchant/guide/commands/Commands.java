package com.virtusa.merchant.guide.commands;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.MethodParameter;
import org.springframework.shell.CompletionContext;
import org.springframework.shell.CompletionProposal;
import org.springframework.shell.ParameterDescription;
import org.springframework.shell.ParameterResolver;
import org.springframework.shell.ValueResult;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import com.virtusa.merchant.guide.dto.ConversionInput;
import com.virtusa.merchant.guide.util.CommandParser;
import com.virtusa.merchant.guide.util.CommandValidator;
import com.virtusa.merchant.guide.util.Constants;
import com.virtusa.merchant.guide.util.InputTypeEnum;

/**
 * Class to process the parsed command based on type of input.
 * 
 * @author Mohit Raj
 *
 */
@ShellComponent
public class Commands {
	
	@Autowired CommandParser commandParser;
	
	@ShellMethod(value= "Translate text from one language to another.")
    public String vp(@ShellOption(optOut=true) List<String> command) {
		ConversionInput ci = commandParser.parse(command);
		InputTypeEnum input = (ci == null || ci.getTokens().isEmpty()) ? InputTypeEnum.UNKNOWN : ci.getInputType();
        Double creditTotal = 0.0;
        String returnMsg = null;
        
        switch (input) {
		case ROMAN:
			Constants.ROMAN_REGISTER.put(ci.getTokens().get(0), ci.getRomanChar().toString());
			returnMsg = "Understood!";
			break;
			
		case CREDIT:
			StringBuilder totalRoman = new StringBuilder();
			StringBuilder cqueryValidate = new StringBuilder();
			for (String token : ci.getTokens()) {
				String str = Constants.ROMAN_REGISTER.get(token);
				if(str == null) {
					return "No value found for Token - " + token;
				}
				totalRoman.append(Constants.ROMAN_REGISTER.get(token)+",");
				cqueryValidate.append(Constants.ROMAN_REGISTER.get(token));
			}
			
			//validate
			if( CommandValidator.validate(cqueryValidate.toString())) {
				//calculate
				Long total = calculateTokenValues(totalRoman.toString()); 
				Double metalVal = ci.getCredits().doubleValue() / total.doubleValue();
				Constants.METAL_REGISTER.put(ci.getMetal(), metalVal);
				returnMsg = "Understood!";
			} else {
				returnMsg = "Validation failed";
			}
			
			break;

		case ROMAN_QUERY:
			StringBuilder totalRomanQuery = new StringBuilder();
			StringBuilder queryValidate = new StringBuilder();
			for (String token : ci.getTokens()) {
				String str = Constants.ROMAN_REGISTER.get(token);
				if(str == null) {
					return "No value found for Token - " + token;
				}
				totalRomanQuery.append(Constants.ROMAN_REGISTER.get(token)+",");
				queryValidate.append(Constants.ROMAN_REGISTER.get(token));
			}
			
			//validate
			if(CommandValidator.validate(queryValidate.toString())) {
				//calculate
				Long total = calculateTokenValues(totalRomanQuery.toString());	
				creditTotal = total.doubleValue();
				returnMsg = "Credit Total = " + creditTotal.toString();
			}
			
			break;
			
		case CREDIT_QUERY:
			StringBuilder totalCreditQuery = new StringBuilder();
			StringBuilder crQueryValidate = new StringBuilder();
			for (String token : ci.getTokens()) {
				String str = Constants.ROMAN_REGISTER.get(token);
				if(str == null) {
					return "No value found for Token - " + token;
				}
				totalCreditQuery.append(Constants.ROMAN_REGISTER.get(token)+",");
				crQueryValidate.append(Constants.ROMAN_REGISTER.get(token));
			}
			
			//validate
			if(CommandValidator.validate(crQueryValidate.toString())) {
				//calculate
				Long total = calculateTokenValues(totalCreditQuery.toString());	
				creditTotal = total * Constants.METAL_REGISTER.get(ci.getMetal());
				returnMsg = "Credit Total = " + creditTotal.toString();
			}
			break;
			
		default:
			returnMsg = "I have no idea what you are talking about";
			break;
		}
        
        return returnMsg;
    }
	
	/**
	 * Calculate total of the token passed in command
	 * 
	 * @param allTokenRomans - String of all tokens send in the command
	 * @return Calculated value
	 */
	private Long calculateTokenValues(String allTokenRomans) {
		String[] sep = allTokenRomans.split(",");
		long total = 0;
		for (int i=0; i< sep.length; i++) {
			int first = Constants.ROMAN_CHARS_MAP.get(sep[i]);
			int second = 0;
			if (i != sep.length -1) {
				second = Constants.ROMAN_CHARS_MAP.get(sep[i+1]);
			}

			if ((second > first) && CommandValidator.canBeSubtracted(sep[i], sep[i+1])) {
				total += second - first;
				i++;
			} else {
				total += Constants.ROMAN_CHARS_MAP.get(sep[i]);				
			}

		}
		
		return total;
	}
	
	 /**
     * Custom parameter resolver to be used for converting tokenized sentence to List of strings
     */
    @Bean
    public ParameterResolver commandParameterResolver() {
        return new ParameterResolver(){
        
            @Override
            public boolean supports(MethodParameter parameter) {
                return parameter.getParameterType().isAssignableFrom(List.class);
            }
        
            /**
             * This implementation simply returns all the words (arguments) present
             * 'Infinite arity'
             */
            @Override
            public ValueResult resolve(MethodParameter methodParameter, List<String> words) {
                return new ValueResult(methodParameter, words);
            }
        
            @Override
            public Stream<ParameterDescription> describe(MethodParameter parameter) {
                return Stream.of(ParameterDescription.outOf(parameter));
            }
        
            @Override
            public List<CompletionProposal> complete(MethodParameter parameter, CompletionContext context) {
                return Collections.emptyList();
            }
        };
    }
}
